GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, ALTER, INDEX, DROP
ON `wms`.* TO 'app_user'@'%';
FLUSH PRIVILEGES;
-- Table for tracking product history
CREATE TABLE IF NOT EXISTS product_history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    action ENUM('add', 'update', 'delete') NOT NULL,
    user VARCHAR(100),
    details TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(id)
);

CREATE TABLE IF NOT EXISTS user_sessions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  username VARCHAR(100),
  ip_address VARCHAR(100),
  user_agent TEXT,
  status ENUM('login','logout') DEFAULT 'login',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
-- ถ้ายังไม่มีคอลัมน์ email ในตาราง users ให้เพิ่ม (unique)
ALTER TABLE `users`
  ADD COLUMN `email` VARCHAR(191) NULL,
  ADD UNIQUE KEY `uniq_users_email` (`email`);

CREATE TABLE password_resets (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  token VARCHAR(255) NOT NULL,
  expires_at DATETIME NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
);



